CorelDRAW is a vector graphics editor developed and marketed by Corel Corporation. It is also the name of the Corel graphics suite, which includes the bitmap-image editor Corel Photo-Paint as well as other graphics-related programs (see below). The latest version is marketed as CorelDraw Graphics Suite (internally, version 24), and was released for Windows and macOS on March 8, 2022.[1] It is designed to edit two-dimensional images such as logos and posters. Reduced-feature Standard and Essentials versions are also offered.

https://en.wikipedia.org/wiki/CorelDRAW

NOTE: THE SAMPLE FILES ARE TAKEN DIRECTLY FROM AN INSTALL OF CORELDRAW VERSION 4. THIS TEMPLATE FORMAT IS DIFFERENT FROM THE V5 CDT SIGNATURE.
