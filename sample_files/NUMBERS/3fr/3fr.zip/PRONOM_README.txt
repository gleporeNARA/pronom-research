3FR (Hasselblad 3F RAW) is a raw image format used by some Hasselblad digital cameras.

http://fileformats.archiveteam.org/wiki/Hasselblad_3FR
